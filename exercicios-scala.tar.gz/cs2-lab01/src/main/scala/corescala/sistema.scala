import akka.actor._
import akka.pattern._
import akka.util.Timeout
import scala.concurrent.duration._
import scala.language.postfixOps
import scala.concurrent.ExecutionContext.Implicits.global

object Sistema extends App {

   implicit val timeout = Timeout(5 seconds)
   val system = ActorSystem("corescala-system")
   //val ator = system.actorOf(Props[ColetorParticipantes])

   val ator = system.actorOf(Props[ColetorParticipantesConfig], "coletorConfig")

   ator ! Participante("Adalberto", "email1@teste.com")
   ator ! Participante("Clodomiro", "email2@teste.com")
   //ator ! Participante("Evangelina", "timeout")
   
   val participantes = ator ? GetParticipantes

   //ator ! Participante("Delcrecio", "desconhecido")   
   ator ! Participante("Maria Antonieta", "email7@teste.com")

   val comMarinaAntonieta = ator ? GetParticipantes

  /* participantes.onSuccess { 
      case msg: Seq[Participante] => msg.foreach(println)
   }*/
   
   /*comMarinaAntonieta.onSuccess { 
      case msg: Seq[Participante] => msg.foreach(println)
   }*/
   
   Thread.sleep(10000)

   system.stop(ator)
   system.terminate()

}
