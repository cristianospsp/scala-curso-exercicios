package corescala

object Utils {
  def aumentar(porcentagem: BigDecimal)( v: BigDecimal): BigDecimal = v + ( v * porcentagem / 100 )
  def aumentar10: BigDecimal => BigDecimal = aumentar(10) _
  def aumentar20: BigDecimal => BigDecimal = aumentar(20) _
  def aumentar30: BigDecimal => BigDecimal = aumentar(30) _

}

case class Funcionario(salario: BigDecimal) {
  def aumentarSalario(f: BigDecimal => BigDecimal): Funcionario = Funcionario(f(salario))
}
