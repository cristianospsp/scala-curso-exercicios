
class Calculadora {
	
	def soma(a:BigDecimal, b:BigDecimal) : BigDecimal = { a+b }
	def subtrai(a:BigDecimal, b:BigDecimal) : BigDecimal = { a-b }
	def multiplica(a:BigDecimal, b:BigDecimal) : BigDecimal = { a*b }
	def divide(a:BigDecimal, b:BigDecimal) : BigDecimal = { a/b }
	def modulo(a:BigDecimal, b:BigDecimal) : BigDecimal = { a%b }

	def + = soma _
	def - = subtrai _
	def * = multiplica _
	def / = divide _
	def % = modulo _

	def teste = "eii...																																																																																																																																																																											"
}
