package corescala

import org.specs2.mutable.{Specification,After}
import akka.actor.{ActorSystem, Props}
import akka.testkit.{ImplicitSender, TestKit}
import ColetorParticipantes._
import scala.collection.mutable._

abstract class AkkaTestkitSpecs2Support extends TestKit(ActorSystem()) 
                                           with After 
                                           with ImplicitSender {
  def after = system.terminate()
}

class ColetorParticipantesSpec extends Specification {

	"Ator Coletor Participantes" >> {
		"deve retornar a lista de participantes correta" >> new AkkaTestkitSpecs2Support{
			val ator = system.actorOf(Props[ColetorParticipantes])
			ator ! Participante("Danilo dos Santos Andrade", "d.s.a@teste.com")
			ator ! Participante("Marcos Cesar Martins", "m.c.m@teste.com")
			
			ator ! GetParticipantes
			
			expectMsg(List("Danilo dos Santos Andrade", "Marcos Cesar Martins"))
		}
	}
}
