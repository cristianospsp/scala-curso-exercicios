package corescala

case class Aluno(id: Int, nome: String, idade: Int, notas: List[Int], media: Option[Double])

object Alunos {

  def encontraMaiores(alunos: List[Aluno]): List[Aluno] = alunos.filter(a => a.idade >= 18)

  def nomes(alunos: List[Aluno]): List[String] = alunos.map(a => a.nome)

  def nomesMaiores(alunos: List[Aluno]): List[String] = nomes { encontraMaiores(alunos) }

  def calculaMedias(alunos: List[Aluno]): List[Aluno] = {
	
    alunos.find(_.notas.size != 3).foreach(a => {
     throw new IllegalStateException(s"${a.nome} nao tem a quantidade certa de notas, notas encontradas: ${a.notas.mkString(", ")}")
    }) 

    alunos map { a => 
     a.copy(media = Option(trunc(a.notas.sum.toDouble / a.notas.size)))
    }

  }

  // use esta função para evitar dizimas periódicas
  def trunc(x: Double) = math.round(x * 100) * 0.01
}
