package corescala

abstract class Pessoa(nome: String) {
  def numDocumento: String
}

class PessoaFisica(val nome: String, val cpf: String) extends Pessoa(nome) {
 override def numDocumento: String = cpf
 override def toString():String = nome
}

class PessoaJuridica(val nome: String, val cnpj: String) extends Pessoa(nome) {
 override def numDocumento: String = cnpj
 override def toString():String = nome
}

object CriadorPessoas {
  def criaPF(nome: String, cpf: String) : PessoaFisica = new PessoaFisica(nome, cpf)
  def criaPJ(nome: String, cnpj: String) : PessoaJuridica = new PessoaJuridica(nome, cnpj)
}
