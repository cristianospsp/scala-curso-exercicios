import akka.actor._
import akka.routing._
import java.util.concurrent.TimeoutException
import java.net.UnknownHostException
import akka.actor.SupervisorStrategy._
import akka.actor.OneForOneStrategy
import scala.concurrent.duration._

case class Participante(nome:String, email:String) {
 override def toString : String = nome
}

case object GetParticipantes {
}

case class EnviarEmail(email:String, mensagem:String)

class ColetorParticipantes extends Actor {

   val enviador = context.actorOf(RoundRobinPool(5).props(Props[EnviadorDeEmail]), "roteador1")

   var participantes: Seq[Participante] = Seq();

   override val supervisorStrategy = OneForOneStrategy(maxNrOfRetries = 10, withinTimeRange = 1 minute) {
      case _: TimeoutException => Resume
      case _: UnknownHostException => Restart
   }

   def receive = {
      case p: Participante => { 
	    participantes = participantes :+ p 
	    enviador ! EnviarEmail(p.email, "Codigos encruados....")
	}
      case GetParticipantes => sender ! participantes
   }

}

class ColetorParticipantesConfig extends Actor {

  val enviador = context.actorOf(FromConfig.props(Props[EnviadorDeEmail]), "enviadorEmails")
  var participantes: Seq[Participante] = Seq();
  def receive = {
      case p: Participante => { 
	    participantes = participantes :+ p 
	    enviador ! EnviarEmail(p.email, "Codigos encruados....")
	}
      case GetParticipantes => sender ! participantes
   }

}


class EnviadorDeEmail extends Actor {

 override def preStart = println("Executando preStart......")
 
 def receive = {
    //case EnviarEmail(email,_) if email == "timeout" => throw new TimeoutException("Lancando TIMEOUT....")
    //case EnviarEmail(email,_) if email == "desconhecido" => throw new UnknownHostException("Lancando UNKNOW...")
    case msg: EnviarEmail => println(s"Self-Path: ${self.path} - MSG para: ${msg.email} | mensagem: ${msg.mensagem}" )
 }


}

