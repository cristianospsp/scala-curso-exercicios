import org.specs2.mutable.Specification
import org.specs2.specification.Scope

class CalculadoraSpec extends Specification {
	
	"fazer calculos com a calculadora" should {
		"somar os numeros" in new CalculadoraScope {
			calc.+(1, 2) must beEqualTo(3)		
		}	

	"subtratir os numeros" in new CalculadoraScope {
			calc.-(2, 1) must beEqualTo(1)		
		}

	"multiplicar dois numeros" in new CalculadoraScope {
			calc.*(2, 1) must beEqualTo(2)		
		}	 		 	
	
	"Dividir dois numeros" in new CalculadoraScope {
			calc./(8, 2) must beEqualTo(4)		
		}

	"Modulo " in new CalculadoraScope {
			calc.%(5, 2) must beEqualTo(1)
		}

	}

}

trait CalculadoraScope extends Scope {
	val calc = new Calculadora
}
